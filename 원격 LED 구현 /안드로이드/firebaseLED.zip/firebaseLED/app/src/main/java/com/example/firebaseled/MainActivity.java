package com.example.firebaseled;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    Button on, off;
    TextView txt1;
    ImageView imgSet;
    Switch Switch;


    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("LED_STATUS");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //객체 생성
        imgSet = (ImageView) findViewById(R.id.imgset);
        Switch = (Switch) findViewById(R.id.switch1);



        this.InitiatizeView();
        this.SetListener();
    }
    public void InitiatizeView() {
        on = (Button) findViewById(R.id.on);
        off = (Button) findViewById(R.id.off);
        txt1 = (TextView) findViewById(R.id.txt1);
        txt1.setText(myRef.getKey());
    }
    public void SetListener() {
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String ledState = (String) dataSnapshot.getValue(); // 스냅샷 값을 받아서 아래 텍스트에 뿌림

                txt1.setText("LED is" + ledState);      //파이어베이스에 저장된 값을 텍스트 뷰에 뿌리는다는 말
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        on.setOnClickListener(new View.OnClickListener() { //on 버튼클릭시
            @Override
            public void onClick(View v) {
                myRef.setValue("ON"); //value 값이 on이면
                imgSet.setImageResource(R.drawable.on); //아래 이미지로 변경
            }
        });
        off.setOnClickListener(new View.OnClickListener() { //off 버튼 클릭시
            @Override
            public void onClick(View v) {
                myRef.setValue("OFF"); //value 값이 off 이면
                imgSet.setImageResource(R.drawable.off); //아래 이미지로 변경
            }
        });
        //스위치 부분 위에 버튼 소스를 똑같이 구현하면 됩니다
        Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true){
                    myRef.setValue("ON");
                    imgSet.setImageResource(R.drawable.on);
                    Toast.makeText(MainActivity.this, "Switch-ON", Toast.LENGTH_SHORT).show(); //메시지 알림

                    //스위치 on시 action
                } else {
                    myRef.setValue("OFF");
                    imgSet.setImageResource(R.drawable.off);
                    Toast.makeText(MainActivity.this, "Switch-OFF", Toast.LENGTH_SHORT).show();
                    //스위치 off시 action
                }
            }
        });

    }



}